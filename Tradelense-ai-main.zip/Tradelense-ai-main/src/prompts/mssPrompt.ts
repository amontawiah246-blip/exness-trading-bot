/**
 * mssPrompt.ts — Gemini layer for the MSS / BOS / POI day-trading strategy.
 *
 * Division of labour (this is the part the old FVG prompt got backwards):
 *   • mss_engine (Python)  reads structure: swings, MSS, BOS, POI zones, relevance, SL, TP1-TP3.
 *   • Gemini               AUDITS that reading in a fixed order (1D → 2H → 15M → cooperation) against
 *                          the raw candles, then picks ONE of the engine's setups or declines.
 *   • This file            refuses any trade Gemini "invents": levels always come from the engine.
 */

export const MSS_SYSTEM_PROMPT = `You are a senior price-action reviewer. The strategy uses ONLY three concepts:
MSS (market structure shift), BOS (break of structure) and POI (point of interest zone).
Never use fair value gaps, order blocks, indicators, news, Fibonacci, volume or any other concept.

YOUR ROLE
A deterministic engine has already read the structure on 1D, 2H and 15M and produced candidate setups
with entry zone, stop loss and TP1-TP3. You are the REVIEWER, not the generator:
- Never create, move or recompute any price level. Entry, SL and targets come from the engine only.
- Never decide from the colour or direction of the latest candles. Decide from structure, read in order.
- You may only (a) agree with the engine's orders, (b) veto some of them, or (c) say NONE. You may flag engine errors.
- The app never just says "WAIT". The engine turns every valid POI into an ORDER:
  * price is AT the POI (state READY)            -> BUY / SELL (market order, entry = touch)
  * POI is still ahead (state WAIT)              -> BUY LIMIT / SELL LIMIT at the zone edge, SL beyond the zone
  * price sits BETWEEN two structures            -> BUY LIMIT and SELL LIMIT together. Whichever fills, the other zone
    is its target, and when price taps that second zone we trade the real continuation from there.
  The engine lists them in "orders". You never add, move or invent an order; you can only veto one by id.

DEFINITIONS
- MSS: first candle-CLOSE break of a swing against the current trend (the shift).
- BOS: candle-close break of a swing in the direction of the new move, after an MSS.
- Leg: one MSS followed by its BOS events. "MSS + 2 BOS" is a confirmed leg.
- POI: the origin zone of the move that made the break (supply for bearish, demand for bullish).

NON-NEGOTIABLE RULES
1. LOOK BACK. Always read what structure printed earlier and in what order. The newest structure is the active
   one; an older opposite leg whose zone is still unbroken is the TARGET and the newer move is only a pullback
   into it. Example: daily bearish MSS + 2 BOS, then a bullish MSS + BOS rally => bias stays SELL, the rally is
   a pullback into the bearish POI. Never say "a bullish MSS printed so the bias is buy".
2. DAILY = BIAS. Only MSS + BOS decide it (a leg needs MSS + 2 BOS to be a legit continuation; the 2nd BOS is
   liquidity, a single BOS may break through or never be reached). Daily POI = the MSS zone, never the BOS.
   If the daily is unclear, the 2H gives the bias, still by looking back.
3. DAILY ZONE TAPPED: when price reaches the daily MSS zone, wait for 2H (else 15M) to print MSS + BOS in the bias
   direction AFTER the tap, then take the RETEST of that BOS. Never chase the break. The target is the low/demand
   (or high/supply) zone price pulled back from, laddered TP1-TP3.
4. 2H = THE STORY. MSS + 1 BOS (price not at a daily MSS zone): the POI is the BOS zone, enter on the retest.
   If price made 2 BOS without tapping the previous BOS zone, those BOS are liquidity and the POI becomes the MSS zone.
   If the daily/2H move has already completed, look for the NEW opportunity: a pullback leg against the bias
   (bullish MSS + BOS in a sell bias) is bought INTO the fresh bearish POI, then sold from there to continue the trend.
5. 15M WORKS WITH 2H, NEVER ALONE. 15M follows the same rules and is used when 2H has no clear direction, or to trade
   into a structural high/low or POI zone. A 15M setup must agree with the 2H story (same direction as the latest
   2H leg, or a pullback INTO a fresh 2H/1D zone). If 15M contradicts 2H without a fresh HTF zone as target => NONE.
6. NESTED CASE: after a 2H bearish MSS + BOS, if the 15M pullback prints a bullish MSS + BOS, prefer buying the
   retest of the 15M BOS into the 2H zone, then sell there. If price skipped that retest and went straight to the
   2H sell zone, SELL at the first tap (the 15M BOS are liquidity; the POI is the MSS).
7. A TOUCH of the POI is enough: no reaction candle required. Stop loss sits beyond the far edge of the POI zone.
   Lower-timeframe confirmation (2H/15M MSS + BOS after the tap) is required ONLY while price is at an untapped DAILY
   zone. For any 2H or 15M zone the trigger is the tap/retest itself. NEVER add "wait for a 15M MSS/BOS" to a 2H setup.
   Every candidate carries a "trigger" sentence written by the engine: copy it as your next_step for WAIT, do not rewrite it.
   Targets: TP3 is the low/high price pulled back from; TP1/TP2 are structure on the way. Do not criticise them as plain R multiples.
11. DAILY ANCHOR: bias.anchor_* is the established daily leg (its MSS zone, MSS level and BOS count). The newest daily leg
   (latest_leg_*) may be a small continuation of it. Describe the daily story from the ANCHOR, never from the small newest leg.
11. FACTS: copy "strength" (confirmed / developing) from the engine's bias exactly; "developing" means fewer than 2 BOS. Quote only
   prices that appear in the data. Do NOT write invalidation levels or stop levels: the engine owns them.
9. THE 30M CHART IS A REFINEMENT TOOL, NOT A SIGNAL SOURCE. Same MSS/BOS rules as the 2H. It never creates, moves or
   overrides an order. The engine reports "refinement_30m" and each order's "refined_by":
   - 15m CLEAR (m15_messy = false): the 15m is used for the entry; 30m is only context.
   - 15m MESSY (overlapping swings, many shifts in a short time): the engine only keeps a 15m order that agrees with the
     latest 30m leg. If 30m has no clear leg there is no order.
   - 30m and 15m DISAGREE: do not prefer the 30m. Decide whether it is a different stage of the same move, a pullback
     toward a higher-timeframe POI, or an invalid setup, using the 2H story. Unresolved => NONE.
   Never veto or keep an order merely because the 30m "looks cleaner".
10. TWO LIMITS: when the engine arms a BUY LIMIT and a SELL LIMIT together, the first one that fills runs into the other
   zone (its TP3), and the second limit then fills and carries the continuation. This is one story, not a contradiction.
8. RELEVANCE: use only recent structure the market can realistically reach. Ignore old or far-away MSS/BOS.

AUDIT PROTOCOL (do it in this order, in your head, then write the short results)
Step 1 DAILY: list the legs oldest -> newest, count BOS, check if any zone is broken or already tapped. Confirm the bias
   and whether the newest daily move is a pullback. Compare with the engine's bias.
Step 2 2H: same, then say which POI rule applies (BOS zone or MSS zone) and whether it is trend or pullback.
Step 3 30M/15M: 15M same as above; if refinement_30m.m15_messy is true say what the 30M clarifies. Say whether they support, refine or contradict the 2H story.
Step 4 COOPERATION: do 1D, 2H and 15M tell one story? Is price at the daily zone? Did the lower TF confirm AFTER the tap?
Step 5 TRAPS: reject if any is true — bias flipped by the newest move; a lone daily BOS treated as a zone; entry on the
   break instead of the retest; 15M trading alone against 2H; stale/far structure; counter-bias trade with no fresh
   structural target; selling at a daily zone before the lower TF confirmed.
Check the engine against the candle tails you receive. If you believe a label, zone or count is wrong, put it in
"engine_errors" and decide NONE or WAIT.

OUTPUT: JSON only, no markdown fences, exactly this shape:
{
 "audit": {
   "daily": "<=40 words: legs in order, BOS count, pullback or trend, zone state",
   "h2": "<=40 words: legs in order, POI rule used (BOS or MSS zone), trend or pullback",
   "m15": "<=40 words: 30M/15M — supports / refines / contradicts the 2H story",
   "cooperation": "<=40 words: how the three timeframes fit together, and where price is relative to the daily zone"
 },
 "engine_errors": ["..."],
 "decision": "TAKE" | "LIMIT" | "NONE",
 "setup_id": "<id of the main order, copied exactly from the engine's orders, or null>",
 "reject_ids": ["<ids of engine orders you VETO because they fail the audit; usually empty>"],
 "grade": "A" | "B" | "C",
 "reason": "<=60 words: why this decision, in the trader's language (MSS, BOS, POI)",
 "invalidation": "<=25 words: what would cancel the idea (use the engine's stop level)",
 "next_step": "for limit orders: the engine trigger sentence(s), verbatim; for a market order: the management plan for TP1-TP3 (<=25 words)"
}
Use TAKE when the engine has a market order (state READY) that passes every rule. Use LIMIT when the engine only has
pending limit orders that pass (or the market order is vetoed but limits remain). Use NONE when nothing valid exists.
If an order passes, do not veto it just because price has not arrived yet: that is exactly what a limit order is for.`;

// ──────────────────────────────────────────────────────────────────────────────

type Candle = { epoch: number; open: number; high: number; low: number; close: number };

export function buildMssUserPrompt(asset: string, engine: any, candlesByTF: Record<string, Candle[]>): string {
  const tails: Record<string, number> = { D1: 40, '2H': 60, '30M': 50, '15M': 60 };
  const candles: Record<string, any[]> = {};
  for (const [label, n] of Object.entries(tails)) {
    const cs = candlesByTF[label];
    if (cs?.length) candles[label] = cs.slice(-n).map(c => [c.epoch, c.open, c.high, c.low, c.close]);
  }
  const payload = {
    asset,
    price_now: engine.price,
    bias: engine.bias,
    daily_bias_zone: engine.bias_zone,
    structure_relevant_only: engine.structure,
    fresh_zones: engine.fresh_zones,
    candidates: engine.setups,
    orders: engine.orders,
    order_mode: engine.order_mode,
    refinement_30m: engine.refinement,
    candles_format: '[epoch_open, open, high, low, close] oldest first (candle tails for verification only)',
    candles,
  };
  return `Review this engine reading for ${asset}. Follow the audit protocol and answer with the JSON only.\n\nDATA\n${JSON.stringify(payload)}`;
}

export function parseDecision(text: string): any | null {
  try {
    const clean = (text || '').replace(/```json|```/g, '').trim();
    const start = clean.indexOf('{');
    const end = clean.lastIndexOf('}');
    if (start < 0 || end < 0) return null;
    return JSON.parse(clean.slice(start, end + 1));
  } catch {
    return null;
  }
}

export type MssVerdict = 'EXECUTE' | 'LIMIT' | 'NONE';

/** Gemini can only keep or veto the engine's orders; it can never add one. */
export function resolveSetup(decision: any, engine: any): { verdict: MssVerdict; setup: any | null; orders: any[] } {
  const setups: any[] = engine?.setups || [];
  if (decision?.decision === 'NONE') return { verdict: 'NONE', setup: null, orders: [] };
  const rejected = new Set<string>(Array.isArray(decision?.reject_ids) ? decision.reject_ids : []);
  const orders: any[] = (engine?.orders || []).filter((o: any) => !rejected.has(o.id));
  if (!orders.length) return { verdict: 'NONE', setup: null, orders: [] };
  const market = orders.find(o => o.kind === 'MARKET');
  const main = market || orders.find(o => o.id === decision?.setup_id) || orders[0];
  const setup = setups.find(x => x.id === main.id) || null;
  if (!setup) return { verdict: 'NONE', setup: null, orders: [] };
  return { verdict: market ? 'EXECUTE' : 'LIMIT', setup, orders };
}

/** Used when no AI model answers: engine rules only. */
export function engineOnlyDecision(engine: any): any {
  const base = { audit: { daily: 'AI review unavailable — engine rules only.', h2: '', m15: '', cooperation: '' }, engine_errors: [], reject_ids: [] };
  const orders: any[] = engine?.orders || [];
  if (orders.length) {
    const market = orders.find(o => o.kind === 'MARKET');
    return {
      ...base, decision: market ? 'TAKE' : 'LIMIT', setup_id: (market || orders[0]).id, grade: market ? 'B' : 'C',
      reason: market ? 'Price is at the POI and the engine rules match; the AI audit was unavailable.'
        : 'The POI is still ahead, so the engine places limit orders at the zone edge; the AI audit was unavailable.',
      invalidation: `Close beyond the stop at ${(market || orders[0]).sl}.`,
      next_step: orders.map(o => o.trigger).join(' '),
    };
  }
  return {
    ...base, decision: 'NONE', setup_id: null, grade: 'C',
    reason: 'No MSS/BOS setup with a fresh POI in reach.', invalidation: '', next_step: 'Wait for new structure.',
  };
}

export function signalFromSetup(
  verdict: MssVerdict, setup: any | null, price: number, bias: any, waitReason?: string, orders: any[] = [], orderMode?: string
): any {
  if (!setup) {
    return {
      direction: 'NEUTRAL', verdict: 'WAIT', entry_low: null, entry_high: null, sl: null,
      tp1: null, tp2: null, tp3: null, score: null, current_price_at_signal: price,
      win_probability_pct: null, expected_value_r: null, hard_block_reason: null, orders: [], order_type: null,
      wait_reason: waitReason || 'No valid MSS/BOS setup right now.',
    };
  }
  return {
    direction: setup.dir === 'bull' ? 'BULLISH' : 'BEARISH',
    // DB/tracker: only a market order is a live trade. Pending limits are stored as WAIT with an order_type.
    verdict: verdict === 'EXECUTE' ? 'EXECUTE' : 'WAIT',
    order_type: setup.order, order_mode: orderMode || null, orders,
    entry_low: setup.zone[0], entry_high: setup.zone[1], entry_price: setup.entry,
    sl: setup.sl, tp1: setup.tp1, tp2: setup.tp2, tp3: setup.tp3,
    score: null, current_price_at_signal: price,
    win_probability_pct: null, expected_value_r: null, hard_block_reason: null,
    wait_reason: verdict === 'EXECUTE' ? null : (setup.trigger || waitReason || null),
  };
}

const fmt = (n: any) => (typeof n === 'number' ? String(Number(n.toPrecision(7))) : 'N/A');

export function renderMssReport(opts: {
  asset: string; engine: any; decision: any; verdict: MssVerdict; setup: any | null; orders?: any[];
  aiUsed: string; positionLine?: string;
}): string {
  const { asset, engine, decision, verdict, setup, aiUsed, positionLine } = opts;
  const orders: any[] = opts.orders || [];
  const b = engine.bias;
  const biasTxt = b ? `${b.dir === 'bull' ? 'BUY' : 'SELL'} (${b.strength}, ${b.tf.toUpperCase()}${b.latest_leg_is_pullback ? ', newest move is a pullback' : ''})` +
    (b.anchor_zone ? ` · anchor leg: ${b.dir === 'bull' ? 'bullish' : 'bearish'} MSS ${String(b.leg_mss_time).slice(0, 10)}, ${b.anchor_bos_count} BOS, MSS zone ${fmt(b.anchor_zone[0])}–${fmt(b.anchor_zone[1])}` : '') : 'No clear bias';
  const banner = (grad: string, glow: string, icon: string, text: string, color: string) =>
    `<div class="relative mb-6 p-[2px] rounded-2xl bg-gradient-to-r ${grad} shadow-[0_0_30px_${glow}]"><div class="flex items-center justify-center gap-3 bg-slate-900 rounded-2xl py-4 px-6"><span class="text-2xl">${icon}</span><span class="text-2xl font-black uppercase tracking-[0.15em] ${color}">${text}</span></div></div>\n\n`;
  let out = '';
  const limits = orders.filter(o => o.kind === 'LIMIT');
  if (verdict === 'EXECUTE' && setup) {
    const sell = setup.dir === 'bear';
    out += sell
      ? banner('from-rose-400 via-red-500 to-orange-500', 'rgba(244,63,94,0.5)', '⬇️', 'SELL NOW (at the POI)', 'text-rose-300')
      : banner('from-emerald-400 via-emerald-500 to-teal-500', 'rgba(16,185,129,0.5)', '⬆️', 'BUY NOW (at the POI)', 'text-emerald-300');
    out += `## 🟢 ${sell ? 'SELL' : 'BUY'} — ${asset}\n\n`;
  } else if (verdict === 'LIMIT') {
    const label = limits.length > 1 ? 'BUY LIMIT + SELL LIMIT' : (setup?.order || 'LIMIT ORDER');
    out += banner('from-sky-400 via-blue-500 to-indigo-500', 'rgba(59,130,246,0.45)', '🕒', label, 'text-sky-200');
    out += `## 🔵 ${label} — ${asset}\n\n`;
  } else {
    out += `## ⚪ NO TRADE — ${asset}\n\n`;
  }

  out += `| Item | Value |\n|---|---|\n| Daily bias | ${biasTxt} |\n| Price now | ${fmt(engine.price)} |\n`;
  if (orders.length) {
    for (const o of orders) {
      out += `| **${o.order}** @ ${fmt(o.entry)} | ${o.tf.toUpperCase()} ${o.type} · ${o.with_bias ? 'with bias' : 'pullback leg'} · zone ${fmt(o.zone[0])} – ${fmt(o.zone[1])} |\n`;
      out += `| ↳ Stop loss | ${fmt(o.sl)} (beyond the POI) |\n`;
      out += `| ↳ TP1 / TP2 / TP3 | ${fmt(o.tp1)} · ${o.tp_labels?.[0] ?? ''} / ${fmt(o.tp2)} · ${o.tp_labels?.[1] ?? ''} / ${fmt(o.tp3)} · ${o.tp_labels?.[2] ?? ''} (${o.rr3}R) |\n`;
    }
    if (decision?.grade) out += `| Grade | ${decision.grade} |\n`;
  }
  out += `\n`;
  if (positionLine) out += `${positionLine}\n\n`;
  if (limits.length > 1) {
    out += `> **Price is between two structures.** Both limits are armed. Whichever fills first, the other zone is its target; when price taps it, take that trade to continue the real trend.\n\n`;
  }
  for (const o of limits) {
    out += `- **${o.order}:** ${o.trigger}${o.on_fill ? ` ${o.on_fill}` : ''}\n`;
  }
  if (limits.length) out += `\n`;

  out += `### How the market is read\n`;
  const a = decision?.audit || {};
  // The AI must not upgrade or downgrade the engine's bias strength ("developing" is not "confirmed").
  const fixStrength = (t: string) => (b && b.strength && b.strength !== 'confirmed') ? t.replace(/\bconfirmed\b/gi, b.strength) : t;
  if (a.daily) out += `- **1D:** ${fixStrength(a.daily)}\n`;
  if (a.h2) out += `- **2H:** ${a.h2}\n`;
  if (a.m15) out += `- **15M:** ${a.m15}\n`;
  if (a.cooperation) out += `- **Together:** ${a.cooperation}\n`;
  out += `\n### Decision\n${decision?.reason || ''}\n`;
  if (verdict === 'EXECUTE' && decision?.next_step) out += `\n**Plan:** ${decision.next_step}\n`;
  // Invalidation comes from the engine's own levels, never from the AI's text.
  if (orders.length) {
    out += `\n**Invalidation (engine levels):**\n`;
    for (const o of orders) {
      const far = o.dir === 'bull' ? o.zone[0] : o.zone[1];
      const beyond = o.dir === 'bull' ? 'below' : 'above';
      out += o.kind === 'LIMIT'
        ? `- ${o.order}: cancel it if price closes ${beyond} ${fmt(far)} before it fills; once filled, a close ${beyond} ${fmt(o.sl)} invalidates it.\n`
        : `- ${o.order}: a close ${beyond} ${fmt(o.sl)} invalidates it.\n`;
    }
  }
  if (Array.isArray(decision?.engine_errors) && decision.engine_errors.length) {
    out += `\n> ⚠️ **Review flagged the engine reading:** ${decision.engine_errors.join('; ')}\n`;
  }
  out += `\n---\n*Strategy: MSS · BOS · POI (1D + 2H + 30M + 15M) │ Analysis: ${aiUsed}*`;
  return out;
}
