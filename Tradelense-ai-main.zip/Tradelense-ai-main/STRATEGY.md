# Day Trading mode — MSS · BOS · POI

Only three concepts: **MSS** (market structure shift), **BOS** (break of structure), **POI** (the zone the move left behind).
No FVG, order blocks, indicators or news in this mode. Code: `mss_engine/` (Python) + `src/prompts/mssPrompt.ts` (Gemini).

## Who does what
| Layer | Job |
|---|---|
| `mss_engine` (deterministic) | swings → MSS/BOS → legs → POI zones → relevance filter → setups, SL, TP1–TP3 |
| Gemini | audits the reading in order 1D → 2H → 15M → cooperation, then picks ONE engine setup or declines |
| `mssPrompt.ts` | refuses anything Gemini invents: entry/SL/TP always come from the engine |

## Rules implemented
- **Look back, never the newest candle.** Daily bias = the latest leg, unless an older opposite leg with MSS + 2 BOS still has an unbroken zone — then the newer move is only a pullback into it (rally after a bearish MSS+2BOS stays SELL).
- **Daily POI = MSS zone.** A leg needs MSS + 2 BOS to count as a continuation (2nd BOS = liquidity).
- **Daily zone tapped →** only 2H/15M legs whose MSS formed *after* the tap count; entry on the retest of their BOS.
- **2H POI = BOS zone**; if 2 BOS formed without tapping the previous BOS zone → POI becomes the MSS zone. Same on 15M.
- **Pullback legs** (against bias) are only traded *into* a fresh structural zone, then the trend is traded from that zone.
- **15M never trades alone:** it must agree with the latest 2H leg, or run into a fresh 2H/1D zone, or 2H has no structure.
- **Nested case:** skipped 15M BOS retest → sell at the first tap of the 2H zone.
- **A touch is enough** (no reaction candle). **SL** = beyond the far edge of the POI (+0.1 ATR).
- **TP1–TP3:** TP3 = final structural objective (e.g. the demand zone price pulled back from); TP1 = nearest structure ≥ 1R, else 1R; TP2 = structure in between, else halfway. No structure → 1R/2R/3R.
- **Relevance:** latest 4 legs per timeframe, max age per timeframe, zones broken by a close are dropped, zones beyond 15 ATR ignored.

## Swing settings (and why)
Swing rule = same as the popular `smartmoneyconcepts` library (`smc.swing_highs_lows`, github.com/joshyattridge/smart-money-concepts):
a swing high is the highest high of N candles before **and** after. Its default N=50 suits long intraday series; on D1 that is far too wide.
Used here (`DEFAULT_CFG` in `mss_engine/analyzer.py`):

| TF | swing_n (candles each side) | min_swing_atr | max_age |
|---|---|---|---|
| 1D | 2 | 1.0 | 150 bars |
| 2H | 3 | 1.0 | 300 bars |
| 15M | 3 | 1.0 | 400 bars |

`min_swing_atr` = a swing only counts if it is at least that many ATR away from the previous opposite swing (noise filter).
**Tuning:** open `/api/mss-structure?asset=XAUUSD`, compare legs/zones with your TradingView marks. Too many tiny legs → raise `min_swing_atr` (1.5) or `swing_n`. Missing obvious swings → lower them.

## Run / test
```
python3 -m mss_engine.test_mss_engine     # or: npm run test:mss
npm install && npm run dev
```
Select **Day Trading** in the dashboard. Scalping/Swing are the old FVG modes, kept as "legacy".

## Orders (no more plain "WAIT")
- Price AT a POI (READY): **BUY / SELL** market order, entry = the touch.
- POI still ahead: **BUY LIMIT / SELL LIMIT** at the near edge of the zone, SL beyond the zone.
- Price between two structures: **BUY LIMIT + SELL LIMIT together**. Whichever fills, the other zone is its
  target (`on_fill` text); at that second zone the real continuation trade is taken.
- Gemini can only veto an engine order by id (`reject_ids`); it cannot add or move one.
- DB/tracker: only market orders are stored as EXECUTE; pending limits are stored as WAIT with `order_type`.

## 30-minute refinement layer
- Timeframes: 1D bias, 2H story, 30M refinement, 15M entries. The 30M uses the same MSS/BOS/POI rules but NEVER creates an order.
- 15M clear -> used as is (30M is context). 15M messy (>= 3 legs in the last 120 bars, or opposite legs with overlapping
  zones) -> a 15M order is kept only if it agrees with the latest 30M leg; no clear 30M leg = no 15M order.
- 30M and 15M disagree and the 2H has no structure to settle it -> no order (WAIT).
- Settings: `use_30m`, `messy_legs`, `messy_window` in `DEFAULT_CFG`. `use_30m: False` = Version A.
- `python -m mss_engine.ab_compare candles_15m.json` replays history without future data and lists where A and B differ.
  It measures differences, not profit.
- Paired limits: each order's TP3 is the other order's entry; both stay armed.
