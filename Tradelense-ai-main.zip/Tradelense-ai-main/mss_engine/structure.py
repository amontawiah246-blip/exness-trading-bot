"""
structure.py - deterministic MSS / BOS / POI reader (no FVG anywhere).

Candles are dicts: {"time": epoch_open_seconds, "open", "high", "low", "close"}.

Definitions used (change here if your charts differ):
  * Swing high/low : fractal with `swing_n` candles on each side (same rule as the
                     smartmoneyconcepts `swing_highs_lows`: highest high / lowest low of
                     N candles before AND after), plus a noise filter: a swing only counts
                     if it is at least `min_swing_atr` x ATR away from the previous
                     opposite swing. Swings ALTERNATE (high, low, high...): two highs in a row
                     with no low between them collapse into the higher one (same clean-up the
                     smartmoneyconcepts library does), so the level that gets broken is always
                     a real swing, never a minor wiggle inside one.
  * Break          : a candle CLOSE beyond the latest unbroken swing level.
  * MSS            : first break AGAINST the current trend (trend flips).
  * BOS            : break WITH the trend after an MSS.
  * Leg            : one MSS followed by its BOS events (MSS + k BOS).
  * Zone (POI)     : the origin candle of the move that made the break, i.e.
                       bearish break -> highest high between the broken low and the break (supply)
                       bullish break -> lowest low  between the broken high and the break (demand)
  * POI choice     : daily = MSS zone.  2H/15m = last BOS zone, unless there are
                     2+ BOS and price never tapped the previous BOS zone before the
                     next BOS (those BOS are liquidity) -> the MSS zone.
  * Relevance      : only legs that are young enough (max_age bars), not invalidated
                     (price never closed beyond the MSS zone), and only the latest
                     `max_legs` legs. Old / far structure is ignored.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

BULL, BEAR = "bull", "bear"
Zone = Tuple[float, float]  # (low, high)


@dataclass
class Event:
    kind: str            # "MSS" | "BOS"
    dir: str             # BULL | BEAR
    idx: int             # candle that closed beyond the level
    time: int
    level: float         # price of the broken swing
    level_idx: int
    zone: Optional[Zone]
    origin_idx: Optional[int]


@dataclass
class Leg:
    dir: str
    mss: Event
    bos: List[Event] = field(default_factory=list)

    @property
    def bos_count(self) -> int:
        return len(self.bos)

    @property
    def end_idx(self) -> int:
        return self.bos[-1].idx if self.bos else self.mss.idx


@dataclass
class Poi:
    kind: str            # "MSS" | "BOS"
    zone: Zone
    dir: str             # BEAR = supply zone, BULL = demand zone
    formed_idx: int      # candle index after which touches are counted
    event: Event


def atr(candles, period: int = 14) -> float:
    if len(candles) < 2:
        return 0.0
    trs = []
    for i in range(1, len(candles)):
        h, l, pc = candles[i]["high"], candles[i]["low"], candles[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    trs = trs[-period:]
    return sum(trs) / len(trs)


def atr_series(candles, period: int = 14):
    """Rolling ATR value for every candle (simple mean of the last `period` true ranges)."""
    out, trs = [0.0] * len(candles), []
    for i in range(len(candles)):
        if i == 0:
            tr = candles[0]["high"] - candles[0]["low"]
        else:
            h, l, pc = candles[i]["high"], candles[i]["low"], candles[i - 1]["close"]
            tr = max(h - l, abs(h - pc), abs(l - pc))
        trs.append(tr)
        w = trs[-period:]
        out[i] = sum(w) / len(w)
    return out


def _swing_high(H, j, n):
    if j - n < 0 or j + n >= len(H):
        return False
    return H[j] > max(H[j - n:j]) and H[j] >= max(H[j + 1:j + n + 1])


def _swing_low(L, j, n):
    if j - n < 0 or j + n >= len(L):
        return False
    return L[j] < min(L[j - n:j]) and L[j] <= min(L[j + 1:j + n + 1])


class Structure:
    def __init__(self, tf, tf_seconds, candles, swing_n=3, zone_mode="range",
                 poi_mode="auto", max_age=300, max_legs=4, min_swing_atr=0.0):
        self.tf = tf
        self.tf_seconds = tf_seconds
        self.candles = candles
        self.swing_n = swing_n
        self.zone_mode = zone_mode
        self.poi_mode = poi_mode
        self.max_age = max_age
        self.max_legs = max_legs
        self.min_swing_atr = min_swing_atr
        self.atr = atr(candles)
        self.events: List[Event] = []
        self.legs: List[Leg] = []
        self.trend: Optional[str] = None
        self.swings: list = []
        self._build()
        self.relevant: List[Leg] = self._relevant()

    # ------------------------------------------------------------------ build
    def _zone_of(self, idx):
        c = self.candles[idx]
        if self.zone_mode == "body":
            return (min(c["open"], c["close"]), max(c["open"], c["close"]))
        return (c["low"], c["high"])

    def _build(self):
        cs = self.candles
        H = [c["high"] for c in cs]
        L = [c["low"] for c in cs]
        C = [c["close"] for c in cs]
        n = self.swing_n
        A = atr_series(cs)
        k = self.min_swing_atr
        swings = []                    # confirmed swings, alternating H/L: [idx, price, kind]
        last_hi = last_lo = None       # latest UNBROKEN swing levels
        min_hi = min_lo = 0            # swings must be at/after the last break
        trend = None

        def origin_for(direction, level_idx, i):
            """Extreme candle between the broken swing and the break candle:
            bearish break -> highest high (supply), bullish break -> lowest low (demand)."""
            a, b = level_idx + 1, i
            if a > b:
                return None
            rng = range(a, b + 1)
            if direction == BEAR:
                return max(rng, key=lambda k: H[k])
            return min(rng, key=lambda k: L[k])

        def add_event(kind, direction, i, lvl):
            o = origin_for(direction, lvl[0], i)
            ev = Event(kind, direction, i, cs[i]["time"], lvl[1], lvl[0],
                       self._zone_of(o) if o is not None else None, o)
            self.events.append(ev)
            if kind == "MSS":
                self.legs.append(Leg(direction, ev))
            elif self.legs and self.legs[-1].dir == direction:
                self.legs[-1].bos.append(ev)

        for i in range(len(cs)):
            c = C[i]
            if trend == BULL:
                if last_hi and c > last_hi[1]:
                    add_event("BOS", BULL, i, last_hi)
                    last_hi, min_hi = None, i
                elif last_lo and c < last_lo[1]:
                    add_event("MSS", BEAR, i, last_lo)
                    trend, last_lo, min_lo = BEAR, None, i
            elif trend == BEAR:
                if last_lo and c < last_lo[1]:
                    add_event("BOS", BEAR, i, last_lo)
                    last_lo, min_lo = None, i
                elif last_hi and c > last_hi[1]:
                    add_event("MSS", BULL, i, last_hi)
                    trend, last_hi, min_hi = BULL, None, i
            else:  # trend unknown: first break only seeds the trend (no label)
                if last_hi and c > last_hi[1]:
                    trend, last_hi, min_hi = BULL, None, i
                elif last_lo and c < last_lo[1]:
                    trend, last_lo, min_lo = BEAR, None, i

            j = i - n  # confirm swing j now that n candles followed it
            if j >= n:
                if _swing_high(H, j, n):
                    prev_lo = next((x for x in reversed(swings) if x[2] == "L"), None)
                    # noise filter: must stand out from the previous swing low by k x ATR
                    if prev_lo is None or H[j] - prev_lo[1] >= k * A[j]:
                        prev = swings[-1] if swings else None
                        if prev and prev[2] == "H" and prev[0] >= min_hi:
                            # two highs in a row with no swing low between = one swing: keep the higher
                            if H[j] > prev[1]:
                                swings[-1] = [j, H[j], "H"]
                                if j >= min_hi:
                                    last_hi = (j, H[j])
                        else:
                            swings.append([j, H[j], "H"])
                            if j >= min_hi:
                                last_hi = (j, H[j])
                if _swing_low(L, j, n):
                    prev_hi = next((x for x in reversed(swings) if x[2] == "H"), None)
                    if prev_hi is None or prev_hi[1] - L[j] >= k * A[j]:
                        prev = swings[-1] if swings else None
                        if prev and prev[2] == "L" and prev[0] >= min_lo:
                            if L[j] < prev[1]:
                                swings[-1] = [j, L[j], "L"]
                                if j >= min_lo:
                                    last_lo = (j, L[j])
                        else:
                            swings.append([j, L[j], "L"])
                            if j >= min_lo:
                                last_lo = (j, L[j])
        self.swings = swings
        self.trend = trend

    # --------------------------------------------------------------- zones
    def touched_between(self, zone: Zone, a: int, b: int) -> bool:
        lo, hi = zone
        for k in range(max(a, 0), min(b, len(self.candles) - 1) + 1):
            c = self.candles[k]
            if c["low"] <= hi and c["high"] >= lo:
                return True
        return False

    def liquidity_levels(self, direction: str, ref: float):
        """Unswept structural swing levels in the trade direction (sell -> swing lows below `ref`,
        buy -> swing highs above `ref`). A level is swept once any later candle wicks through it."""
        out = []
        for idx, price, kind in self.swings:
            if direction == BEAR and kind == "L" and price < ref:
                if all(c["low"] > price for c in self.candles[idx + 1:]):
                    out.append((price, idx))
            elif direction == BULL and kind == "H" and price > ref:
                if all(c["high"] < price for c in self.candles[idx + 1:]):
                    out.append((price, idx))
        return out

    def extreme_between(self, direction: str, a: int, b: int):
        """Lowest low (direction BEAR) / highest high (BULL) of candles a..b -> (price, idx) or None."""
        a, b = max(a, 0), min(b, len(self.candles) - 1)
        if a > b:
            return None
        rng = range(a, b + 1)
        if direction == BEAR:
            k = min(rng, key=lambda x: self.candles[x]["low"])
            return self.candles[k]["low"], k
        k = max(rng, key=lambda x: self.candles[x]["high"])
        return self.candles[k]["high"], k

    def zone_broken(self, zone: Zone, direction: str, after_idx: int) -> bool:
        """Supply (BEAR) is broken by a close above it; demand (BULL) by a close below."""
        for k in range(after_idx + 1, len(self.candles)):
            cl = self.candles[k]["close"]
            if direction == BEAR and cl > zone[1]:
                return True
            if direction == BULL and cl < zone[0]:
                return True
        return False

    def leg_poi(self, leg: Leg) -> Optional[Poi]:
        if leg.bos_count == 0:
            return None
        if self.poi_mode == "mss":
            ev = leg.mss
        else:
            ev = leg.bos[-1]
            if leg.bos_count >= 2:
                prev = leg.bos[-2]
                # two BOS without tapping the previous BOS zone = liquidity -> MSS zone
                if prev.zone is None or not self.touched_between(prev.zone, prev.idx + 1, ev.idx - 1):
                    ev = leg.mss
        if ev.zone is None:
            return None
        return Poi(ev.kind, ev.zone, leg.dir, leg.end_idx, ev)

    def _relevant(self) -> List[Leg]:
        n = len(self.candles)
        out = []
        for leg in self.legs:
            if leg.end_idx < n - self.max_age:
                continue
            if leg.mss.zone and self.zone_broken(leg.mss.zone, leg.dir, leg.end_idx):
                continue
            out.append(leg)
        return out[-self.max_legs:]


def build_structure(candles, tf, tf_seconds, **kw) -> Structure:
    return Structure(tf, tf_seconds, candles, **kw)
