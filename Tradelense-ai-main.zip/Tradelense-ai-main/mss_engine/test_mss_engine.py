"""Run from the project root:  python -m mss_engine.test_mss_engine   (no network, synthetic candles)"""
from mss_engine.structure import build_structure, BULL, BEAR
from mss_engine.analyzer import analyze


def path15(points, start=1_700_006_400, wick=0.4):
    """points: [(price, bars_to_reach)], first item = start price. Returns 15m candles."""
    cs, t, prev = [], start, points[0][0]
    for price, bars in points[1:]:
        for k in range(1, bars + 1):
            c = prev + (price - prev) * k / bars
            o = cs[-1]["close"] if cs else points[0][0]
            cs.append({"time": t, "open": o, "close": c, "high": max(o, c) + wick, "low": min(o, c) - wick})
            t += 900
        prev = price
    return cs


def agg(cs, n):
    out = []
    for i in range(0, len(cs) - n + 1, n):
        g = cs[i:i + n]
        out.append({"time": g[0]["time"], "open": g[0]["open"], "close": g[-1]["close"],
                    "high": max(x["high"] for x in g), "low": min(x["low"] for x in g)})
    return out


def scenario():
    """Daily: bearish MSS + 2 BOS, bullish rally (itself MSS+BOS) back INTO the bearish MSS zone,
    then 2H bearish MSS + BOS and a retest of the BOS zone."""
    D = 96
    pts = [(100, 0)] + [(p, 6 * D) for p in [150, 125, 180, 150, 220, 170, 140, 160, 110, 130, 80, 100, 120]]
    pts += [(p, int(d * D)) for p, d in [(150, 4), (140, 2), (175, 4), (165, 2), (214, 6)]]
    pts += [(p, int(d * D)) for p, d in [(196, 1.5), (204, 1), (186, 1.5), (196, 1), (170, 1.5), (150, 1), (196, 1.5), (180, 1)]]
    return path15(pts)


def feed(cs, cut):
    c = cs[:cut + 1]
    return {"15m": c, "30m": agg(c, 2), "2h": agg(c, 8), "1d": agg(c, 96)}


def test_labels():
    pts = [100, 110, 104, 120, 112, 130, 118, 105, 112, 98, 104, 90]
    cs = path15([(pts[0], 0)] + [(p, 8) for p in pts[1:]], wick=0.15)
    s = build_structure(agg(cs, 1), "2h", 7200, swing_n=2)
    got = [(e.kind, e.dir) for e in s.events]
    assert ("MSS", BEAR) in got and got.count(("BOS", BEAR)) >= 1, got
    leg = [l for l in s.legs if l.dir == BEAR][-1]
    assert leg.mss.zone[1] >= 129, f"supply zone must sit at the 130 high, got {leg.mss.zone}"
    print("labels OK:", got, "zone", leg.mss.zone)


def test_bias_not_flipped_by_pullback():
    cs = scenario()
    r = analyze(feed(cs, 9700))
    assert r["bias"]["dir"] == BEAR and r["bias"]["latest_leg_is_pullback"], r["bias"]
    assert r["bias_zone"]["tapped"], r["bias_zone"]
    print("bias OK:", r["bias"])


def test_ready_sell_at_retest():
    cs = scenario()
    r = analyze(feed(cs, 10074))
    b = r["best"]
    assert b and b["action"] == "SELL" and b["state"] == "READY" and b["tf"] == "2h", r["setups"]
    assert b["sl"] > b["zone"][1], "stop loss must sit above the POI zone for a sell"
    assert b["tp3"] < b["tp2"] < b["tp1"] < b["entry"] < b["sl"], b
    sig = r["signal"]
    assert sig["verdict"] == "EXECUTE" and sig["direction"] == "BEARISH" and sig["tp3"] == b["tp3"]
    print("ready OK:", b["id"], "entry", b["entry"], "sl", b["sl"], "tps", b["tp1"], b["tp2"], b["tp3"], b["tp_labels"])


def test_no_signal_when_far_from_zone():
    cs = scenario()
    r = analyze(feed(cs, 9840))
    assert r["best"] is None
    print("far-from-zone OK (WAIT only):", [s["id"] for s in r["setups"]])


def test_old_daily_tap_seen_with_short_15m_window():
    cs = scenario()
    full = feed(cs, 9700)
    short = dict(full)
    short["15m"] = full["15m"][-600:]          # ~6 days of 15m only; the daily tap was weeks earlier
    r = analyze(short)
    assert r["bias_zone"]["tapped"], r["bias_zone"]
    print("old-tap OK:", r["bias_zone"])


def test_ladder_without_structure_is_1R_2R_3R():
    from mss_engine.analyzer import _ladder, BEAR
    picks, ttype, _ = _ladder(BEAR, 100.0, 2.0, [], (0, 0), {"reach_atr": 15})
    assert [p[0] for p in picks] == [98.0, 96.0, 94.0] and ttype == "rr", picks
    print("ladder OK:", [p[1] for p in picks])


def test_ladder_objective_is_tp3_and_structure_levels_used():
    from mss_engine.analyzer import _ladder, BEAR
    cfg = {"reach_atr": 15}
    # sell from 4343, risk 34: the low price pulled back from (4118) must be TP3, a 2H swing low in between is used
    levels = [(4250.0, "2H swing low (liquidity)", "2h")]
    obj = (4118.0, "2H low the pullback started from", "2h")
    picks, ttype, tf = _ladder(BEAR, 4343.0, 34.0, [], (0, 0), cfg, levels, obj)
    assert picks[2][0] == 4118.0 and picks[0][0] == 4250.0, picks
    assert picks[0][0] > picks[1][0] > picks[2][0], picks
    print("objective ladder OK:", [(round(p[0], 1), p[1]) for p in picks])


def test_swings_alternate():
    # two highs in a row with no low between must collapse into the higher one
    pts = [100, 112, 108, 116, 100, 90]
    cs = path15([(pts[0], 0)] + [(p, 6) for p in pts[1:]], wick=0.1)
    s = build_structure(agg(cs, 1), "2h", 7200, swing_n=2)
    kinds = [x[2] for x in s.swings]
    assert all(a != b for a, b in zip(kinds, kinds[1:])), kinds
    print("alternating swings OK:", [(x[2], round(x[1], 1)) for x in s.swings])


def test_wait_trigger_has_no_extra_confirmation():
    cs = scenario()
    r = analyze(feed(cs, 9760))
    st = r["setups"][0]
    assert "No extra lower-timeframe confirmation" in st["trigger"], st["trigger"]
    assert r["signal"]["wait_reason"] == st["trigger"] or r["signal"]["verdict"] == "EXECUTE"
    print("trigger OK")


def test_order_types():
    import random
    # market order when price is at the POI
    cs = scenario()
    # (the READY case is covered by the 'ready' test: its order must be a market BUY/SELL)
    # price between two structures -> BUY LIMIT + SELL LIMIT together, each pointing at the other zone
    rnd = random.Random(6)
    pts, p = [(150, 0)], 150
    for _ in range(40):
        p = max(20, p + rnd.choice([-1, 1]) * rnd.uniform(6, 28))
        pts.append((p, int(rnd.uniform(0.6, 2.2) * 96)))
    cs2 = path15(pts)
    r = analyze(feed(cs2, 4591))
    assert r["order_mode"] == "LIMIT_BOTH", r["order_mode"]
    kinds = sorted(o["order"] for o in r["orders"])
    assert kinds == ["BUY LIMIT", "SELL LIMIT"], kinds
    buy = next(o for o in r["orders"] if o["order"] == "BUY LIMIT")
    sell = next(o for o in r["orders"] if o["order"] == "SELL LIMIT")
    assert buy["entry"] < r["price"] < sell["entry"], (buy["entry"], r["price"], sell["entry"])
    assert "SELL LIMIT" in buy["on_fill"] and "BUY LIMIT" in sell["on_fill"]
    # chained: each trade ends exactly where the other begins
    assert buy["tp3"] == sell["entry"] and sell["tp3"] == buy["entry"], (buy, sell)
    assert buy["entry"] < buy["tp1"] < buy["tp2"] < buy["tp3"], buy
    assert sell["entry"] > sell["tp1"] > sell["tp2"] > sell["tp3"], sell
    assert r["signal"]["verdict"] == "WAIT" and r["signal"]["order_type"] in kinds
    print("order types OK:", r["order_mode"], [(o["order"], o["entry"]) for o in r["orders"]])


def test_30m_refinement():
    cs = scenario()
    # Version A (no 30m) vs Version B (30m): 30m only exists as structure context, never as its own setup
    a = analyze(feed(cs, 9760), cfg={"use_30m": False})
    b = analyze(feed(cs, 9760))
    assert "30m" not in a["structure"] and "30m" in b["structure"]
    assert all(st["tf"] in ("2h", "15m") for st in b["setups"]), "30m must never create a setup"
    assert a["refinement"]["mode"] == "off" and b["refinement"]["mode"] in ("15m-clear", "30m-guided")
    # force "messy 15m": then every 15m setup must be guided by (and agree with) the latest 30m leg
    n_checked = 0
    for cut in range(6000, len(cs) - 1, 200):
        r = analyze(feed(cs, cut), cfg={"messy_legs": 0})
        m30 = r["refinement"]["m30_latest"]
        for st in r["setups"]:
            if st["tf"] == "15m":
                n_checked += 1
                assert st["refined_by"] == "30m" and st["dir"] == m30, (st["id"], m30)
    # no 30m data at all -> engine still works (30m is optional)
    c = feed(cs, 9760); c.pop("30m")
    assert analyze(c)["refinement"]["mode"] == "off"
    print("30m refinement OK (A/B flag, never a signal source, messy-15m gating on", n_checked, "setups)")


def test_small_new_leg_does_not_hide_confirmed_leg():
    """Daily: bear MSS+2BOS (May) -> bull rally -> bear leg with 3 BOS -> NEW small bear leg (MSS+1 BOS).
    Bias must stay SELL *confirmed* and anchor on the big leg, not 'developing' on the small one."""
    import types
    from mss_engine.analyzer import _bias
    def leg(d, bos):
        return types.SimpleNamespace(dir=d, bos_count=bos)
    legs = [leg("bear", 3), leg("bull", 1), leg("bear", 3), leg("bear", 1)]
    s = types.SimpleNamespace(relevant=legs)
    b = _bias({"1d": s})
    assert b["dir"] == "bear" and b["strength"] == "confirmed" and b["leg"] is legs[2], b
    assert b["pullback"] is False
    # an older opposite confirmed leg still wins over a small newest leg (pullback into it)
    legs2 = [leg("bull", 2), leg("bear", 1)]
    b2 = _bias({"1d": types.SimpleNamespace(relevant=legs2)})
    assert b2["dir"] == "bull" and b2["pullback"] is True
    print("bias anchor OK")


if __name__ == "__main__":
    test_labels()
    test_bias_not_flipped_by_pullback()
    test_ready_sell_at_retest()
    test_no_signal_when_far_from_zone()
    test_old_daily_tap_seen_with_short_15m_window()
    test_ladder_without_structure_is_1R_2R_3R()
    test_ladder_objective_is_tp3_and_structure_levels_used()
    test_swings_alternate()
    test_wait_trigger_has_no_extra_confirmation()
    test_order_types()
    test_30m_refinement()
    test_small_new_leg_does_not_hide_confirmed_leg()
    print("ALL OK")
