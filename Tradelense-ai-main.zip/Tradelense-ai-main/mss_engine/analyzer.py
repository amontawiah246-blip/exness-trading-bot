"""
analyzer.py - 1D / 2H / 15m MSS + BOS + POI engine (no FVG, no order blocks, no indicators).

analyze(data) -> dict:
  bias       daily bias (2H fallback) read by LOOKING BACK, never from the newest candle
  structure  per-timeframe legs / zones (only RELEVANT ones)
  setups     READY (zone touched now) or WAIT (watchlist) setups, each with SL and TP1-TP3
  best       the READY setup to consider first (or None)

Entry types
  RETEST : price returns to the POI of the latest leg of a timeframe -> trade that leg's way.
           A leg against the bias is a pullback leg: only traded INTO a fresh structural zone.
  TAP    : price reaches the POI of an EARLIER opposite leg (the zone the newer leg was
           heading into) -> trade from that zone.
Daily zone rule : once the daily bias zone is tapped, only 2H/15m legs whose MSS formed AFTER
                  the tap are accepted (lower timeframe must confirm).
Cooperation rule: a 15m setup must agree with the 2H story (same direction as the latest 2H leg,
                  or a pullback INTO a fresh 2H/1D zone, or 2H has no structure at all).
30m refinement : the 30m chart NEVER creates a setup. It only clarifies a MESSY 15m chart (>= `messy_legs`
                  legs in the last `messy_window` bars, or opposite legs whose zones overlap):
                  messy 15m -> a 15m setup must agree with the latest 30m leg, and if 30m has no clear leg
                  there is no 15m setup; clear 15m -> 15m is used as is (30m is context only);
                  30m vs 15m disagree and 2H has no structure to settle it -> no setup (WAIT).
Stop loss       : beyond the far edge of the POI zone (+ small ATR buffer).
Take profit     : TP1..TP3 laddered along fresh opposite structural zones (the demand/supply
                  zone price pulled back from comes last), padded with 1R/2R/3R when structure
                  runs out.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone

from .structure import BULL, BEAR, build_structure

DEFAULT_CFG = {
    "tfs": {
        "1d":  {"seconds": 86400, "swing_n": 2, "max_age": 150, "poi_mode": "mss",  "min_swing_atr": 1.0},
        "2h":  {"seconds": 7200,  "swing_n": 3, "max_age": 300, "poi_mode": "auto", "min_swing_atr": 1.0},
        "30m": {"seconds": 1800,  "swing_n": 3, "max_age": 350, "poi_mode": "auto", "min_swing_atr": 1.0},
        "15m": {"seconds": 900,   "swing_n": 3, "max_age": 400, "poi_mode": "auto", "min_swing_atr": 1.0},
    },
    "use_30m": True,          # False = "Version A" (1D + 2H + 15m) for A/B comparison
    "messy_legs": 3,          # 15m is MESSY when this many legs printed in the last `messy_window` 15m bars
    "messy_window": 120,
    "zone_mode": "range",     # "range" = whole origin candle, "body" = candle body
    "max_legs": 4,            # only the latest N legs per timeframe are relevant
    "reach_atr": 15,          # ignore zones farther than this many ATR (of the zone's own TF)
    "ready_window": 2,        # zone first touched within the last N 15m bars = READY
    "sl_buffer_atr": 0.1,
    "min_rr": 1.0,
    "touch_gap_bars": 96,     # 15m bars; separates one tap of a zone from the next
}

LABELS = {"D1": "1d", "1D": "1d", "2H": "2h", "15M": "15m", "15m": "15m", "30M": "30m", "30m": "30m", "2h": "2h", "1d": "1d"}


def _iso(t):
    return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")


def _merge(cfg):
    out = copy.deepcopy(DEFAULT_CFG)
    for k, v in (cfg or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            for k2, v2 in v.items():
                if isinstance(v2, dict) and isinstance(out[k].get(k2), dict):
                    out[k][k2].update(v2)
                else:
                    out[k][k2] = v2
        else:
            out[k] = v
    return out


def normalize_candles(raw):
    """Accepts server candles {epoch|time, open, high, low, close} -> engine candles."""
    out = []
    for c in raw or []:
        t = c.get("time", c.get("epoch"))
        if t is None:
            continue
        out.append({"time": int(t), "open": float(c["open"]), "high": float(c["high"]),
                    "low": float(c["low"]), "close": float(c["close"])})
    return out


def _touch_series(data, live_bar):
    """
    Candles used to detect zone touches. The 15m series is too short to reach back to a daily
    zone formed weeks ago, so older time is covered by 2H candles, and older still by daily
    candles (coarser, but a tap is still a tap). The newest bars are always real 15m bars.
    """
    m15 = list(data["15m"]) + ([live_bar] if live_bar else [])
    out = m15
    t0 = m15[0]["time"]
    if data.get("2h"):
        older = [c for c in data["2h"] if c["time"] + 7200 <= t0]
        out = older + out
        t0 = out[0]["time"]
    if data.get("1d"):
        older = [c for c in data["1d"] if c["time"] + 86400 <= t0]
        out = older + out
    return out


def _touch_indices(low, zone, start_time):
    lo, hi = zone
    return [i for i, c in enumerate(low)
            if c["time"] >= start_time and c["low"] <= hi and c["high"] >= lo]


def _formed_time(s, poi):
    return s.candles[poi.formed_idx]["time"] + s.tf_seconds  # close of the forming candle


# ------------------------------------------------------------------- bias
def _bias(S):
    """
    Look back, never judge the newest move alone.
    latest leg = newest MSS+BOS structure. If an OLDER leg in the opposite direction
    (MSS + 2 BOS on the daily, MSS + BOS on 2H) still has an unbroken zone, the latest
    leg is only a pullback into that zone, so the bias is the older leg's direction.
    Daily first; 2H is the fallback when the daily has no usable structure.
    """
    for tf, need in (("1d", 2), ("2h", 1)):
        s = S.get(tf)
        if not s:
            continue
        legs = [l for l in s.relevant if l.bos_count >= 1]   # relevant = unbroken + recent
        if not legs:
            continue
        latest = legs[-1]
        anchor = latest
        for e in reversed(legs[:-1]):
            if e.dir != latest.dir and e.bos_count >= need:
                anchor = e
                break
        if anchor is latest and latest.bos_count < need:
            # The newest leg is still small (e.g. MSS + 1 BOS on the daily). If an OLDER leg in the SAME direction
            # is already fully built (MSS + 2 BOS), that leg is the established story and the new one continues it.
            for e in reversed(legs[:-1]):
                if e.dir == latest.dir and e.bos_count >= need:
                    anchor = e
                    break
        strength = "confirmed" if anchor.bos_count >= need else "developing"
        return {"dir": anchor.dir, "strength": strength, "tf": tf, "leg": anchor, "s": s,
                "latest_dir": latest.dir, "latest": latest, "pullback": anchor.dir != latest.dir}
    return None


def _fresh_zones(S, low):
    """Untouched, unbroken structural zones of every timeframe (targets / pullback goals)."""
    out = []
    for tf, s in S.items():
        for leg in s.relevant:
            poi = s.leg_poi(leg)
            if not poi or s.zone_broken(poi.zone, leg.dir, poi.formed_idx):
                continue
            if _touch_indices(low, poi.zone, _formed_time(s, poi)):
                continue
            out.append({"tf": tf, "dir": leg.dir, "zone": poi.zone, "kind": poi.kind, "atr": s.atr})
    return out


def _ladder(direction, entry, risk, zones, own_zone, cfg, levels=None, objective=None):
    """
    TP1..TP3.
      TP3 = final structural objective: the farthest fresh opposite zone in reach
            (e.g. the demand zone price pulled back from, for a sell).
      TP1 = nearest structural level at least 1R away, else 1R.
      TP2 = a structural level between them, else the halfway point.
      No structure in reach -> 1R / 2R / 3R.
    levels    : unswept structural swing lows/highs [(price, label, tf)] used as extra TP steps.
    objective : (price, label, tf) = the low/high price pulled back from. When valid it IS TP3.
    """
    sign = -1 if direction == BEAR else 1
    cands = []                                   # (price, label, tf)
    for z in zones:
        if z["zone"] == own_zone:
            continue
        lo, hi = z["zone"]
        reach = cfg["reach_atr"] * z["atr"]
        if direction == BEAR and z["dir"] == BULL and hi < entry and entry - hi <= reach:
            cands.append((hi, f"{z['tf'].upper()} demand zone", z["tf"]))
        elif direction == BULL and z["dir"] == BEAR and lo > entry and lo - entry <= reach:
            cands.append((lo, f"{z['tf'].upper()} supply zone", z["tf"]))
    for price, label, tf_ in (levels or []):
        if (direction == BEAR and price < entry) or (direction == BULL and price > entry):
            cands.append((price, label, tf_))
    cands = [c for c in cands if abs(c[0] - entry) >= 1.0 * risk]
    if objective and ((direction == BEAR and objective[0] < entry) or (direction == BULL and objective[0] > entry)) \
            and abs(objective[0] - entry) >= 1.6 * risk:
        d_obj = abs(objective[0] - entry)
        cands = [c for c in cands if abs(c[0] - entry) < d_obj - 0.3 * risk] + [objective]
    cands.sort(key=lambda c: abs(c[0] - entry))
    kept = []                                    # drop steps that are practically the same level
    for c in cands:
        if kept and abs(c[0] - kept[-1][0]) < 0.5 * risk:
            if c is objective:
                kept[-1] = c
            continue
        kept.append(c)
    cands = kept
    if not cands:
        picks = [(entry + sign * m * risk, f"{m}R", None) for m in (1, 2, 3)]
        return picks, "rr", None

    final = cands[-1]
    d3 = abs(final[0] - entry)
    inner = cands[:-1]
    # TP1: nearest structure in the first half of the way; else 1R (short targets) or a third of the way
    tp1 = next((c for c in inner if abs(c[0] - entry) <= 0.5 * d3), None)
    if tp1 is None:
        if d3 <= 6 * risk:
            tp1 = (entry + sign * risk, "1R", None)
        else:
            tp1 = (entry + sign * d3 / 3, "1/3 of the way to TP3", None)
    d1 = abs(tp1[0] - entry)
    mid = next((c for c in inner if c is not tp1 and d1 + 0.3 * risk < abs(c[0] - entry) < d3 - 0.3 * risk), None)
    if mid is None:
        mid = (entry + sign * (d1 + d3) / 2, "halfway to TP3", None)
    picks = [tp1, mid, final]
    if abs(final[0] - entry) < 1.6 * risk:           # objective too close for a 3-step ladder
        picks = [(entry + sign * m * risk, f"{m}R", None) for m in (1, 2, 3)]
        return picks, "rr", None
    n_struct = sum(1 for p in picks if p[2])
    return picks, ("structure" if n_struct == 3 else "mixed"), final[2]


def _make_setup(kind, tf, s, leg, poi, state, price, zones, cfg, with_bias, first_touch, tap_target=None,
                levels=None, objective=None):
    d = leg.dir
    lo, hi = poi.zone
    buf = cfg["sl_buffer_atr"] * s.atr
    if d == BEAR:
        sl, near = hi + buf, lo
    else:
        sl, near = lo - buf, hi
    entry = price if state == "READY" else near
    risk = (sl - entry) if d == BEAR else (entry - sl)
    if risk <= 0:
        return None
    levels = levels(d, entry) if callable(levels) else levels
    if tap_target is not None:      # the demand/supply zone edge the pullback leg started from
        levels = list(levels or []) + [(tap_target, f"{tf.upper()} {'demand' if d == BEAR else 'supply'} zone price pulled back from", tf)]
    picks, ttype, first_tf = _ladder(d, entry, risk, zones, poi.zone, cfg, levels, objective)
    picks = sorted(picks, key=lambda c: abs(c[0] - entry))
    tps = [p[0] for p in picks]
    rr1 = abs(tps[0] - entry) / risk
    rr3 = abs(tps[2] - entry) / risk
    if rr3 < cfg["min_rr"]:
        return None
    return {
        "id": f"{tf}:{kind}:{d}:{round(lo, 5)}-{round(hi, 5)}",
        "type": kind, "tf": tf, "dir": d, "action": "BUY" if d == BULL else "SELL",
        "state": state, "with_bias": with_bias,
        "order": (("BUY" if d == BULL else "SELL") if state == "READY"
                  else ("BUY LIMIT" if d == BULL else "SELL LIMIT")),
        "poi_kind": poi.kind, "zone": [lo, hi],
        "entry": round(entry, 5), "sl": round(sl, 5),
        "tp1": round(tps[0], 5), "tp2": round(tps[1], 5), "tp3": round(tps[2], 5),
        "tp_labels": [p[1] for p in picks],
        "rr1": round(rr1, 2), "rr3": round(rr3, 2),
        "target_type": ttype, "target_tf": first_tf,
        "leg": {"mss_time": _iso(leg.mss.time), "bos_count": leg.bos_count},
        "first_touch_time": _iso(first_touch) if first_touch else None,
    }


def _chain(st, final_price, label):
    """Make `final_price` (the paired order's entry) this setup's TP3 and re-space TP1/TP2 before it."""
    entry, risk = st["entry"], abs(st["entry"] - st["sl"])
    d3 = abs(final_price - entry)
    if d3 < 1.0 * risk:
        return                                   # too tight to chain: keep the engine's own ladder
    sign = 1 if final_price > entry else -1
    keep = [(st[k], st["tp_labels"][i]) for i, k in enumerate(("tp1", "tp2"))
            if abs(st[k] - entry) < d3 - 0.3 * risk]
    if len(keep) == 2 and abs(keep[1][0] - entry) <= abs(keep[0][0] - entry):
        keep = keep[:1]
    if len(keep) == 0:
        keep = [(entry + sign * d3 / 3, "1/3 of the way to TP3"), (entry + sign * 2 * d3 / 3, "2/3 of the way to TP3")]
    elif len(keep) == 1:
        d1 = abs(keep[0][0] - entry)
        keep.append((entry + sign * (d1 + d3) / 2, "halfway to TP3"))
    keep.sort(key=lambda x: abs(x[0] - entry))
    st["tp1"], st["tp2"], st["tp3"] = round(keep[0][0], 5), round(keep[1][0], 5), round(final_price, 5)
    st["tp_labels"] = [keep[0][1], keep[1][1], f"the {label} (where the opposite trade begins)"]
    st["rr1"], st["rr3"] = round(abs(st["tp1"] - entry) / risk, 2), round(d3 / risk, 2)


def _trigger(st, bias_zone):
    """What exactly we wait for. Fixed by the engine so the AI cannot invent extra confirmations."""
    act = st["order"] if st.get("state") == "WAIT" else st["action"]
    z = f"{st['zone'][0]:.5g}-{st['zone'][1]:.5g}"
    tf = st["tf"].upper()
    if st["type"] == "TAP":
        base = (f"{act} at {st['entry']:.5g}: fills on the FIRST TAP of the {tf} {st['poi_kind']} zone {z} (the earlier {tf} structure the "
                f"pullback is running into). A touch is enough.")
    else:
        base = f"{act} at {st['entry']:.5g}: fills on the RETEST (touch) of the {tf} {st['poi_kind']} zone {z}. Never on the break itself."
    if st["with_bias"] and bias_zone and bias_zone.get("tapped"):
        base += " The daily zone was already tapped and this leg formed after the tap, so the lower-timeframe confirmation is done."
    base += " No extra lower-timeframe confirmation is required: that rule only applies while price sits at an untapped DAILY zone."
    return base


# ----------------------------------------------------------------- analyze
def analyze(data, cfg=None, live_bar=None):
    """
    data     : {"1d": [...], "2h": [...], "15m": [...]} CLOSED candles, oldest first
               (keys may also be D1 / 2H / 15M; candles may use `epoch` or `time`).
    live_bar : optional forming 15m candle (used only for price + touch detection).
    """
    cfg = _merge(cfg)
    data = {LABELS.get(k, k): normalize_candles(v) for k, v in data.items()}
    if live_bar:
        live_bar = normalize_candles([live_bar])[0]
    S = {}
    for tf, p in cfg["tfs"].items():
        if tf == "30m" and not cfg.get("use_30m", True):
            continue
        if tf in data and len(data[tf]) > 20:
            S[tf] = build_structure(
                data[tf], tf, p["seconds"], swing_n=p["swing_n"], zone_mode=cfg["zone_mode"],
                poi_mode=p["poi_mode"], max_age=p["max_age"], max_legs=cfg["max_legs"],
                min_swing_atr=p.get("min_swing_atr", 0.0))
    if "15m" not in data or len(data["15m"]) < 2:
        raise ValueError("15m candles are required")
    low = _touch_series(data, live_bar)
    price = low[-1]["close"]
    n_low = len(low)
    ready_from = n_low - cfg["ready_window"]

    bias = _bias(S)
    zones = _fresh_zones(S, low)

    # daily bias zone: has it been tapped? -> lower TF must confirm after the tap
    bias_zone_info, touch_start = None, None
    if bias and bias["tf"] == "1d":
        poi = bias["s"].leg_poi(bias["leg"])
        if poi:
            idxs = _touch_indices(low, poi.zone, _formed_time(bias["s"], poi))
            if idxs:
                start = idxs[-1]
                gap = cfg["touch_gap_bars"] * 900
                for k in range(len(idxs) - 1, 0, -1):
                    if low[idxs[k]]["time"] - low[idxs[k - 1]]["time"] > gap:
                        break
                    start = idxs[k - 1]
                touch_start = low[start]["time"]
            bias_zone_info = {"zone": list(poi.zone), "tapped": bool(idxs),
                              "at_zone_now": bool(idxs and idxs[-1] >= n_low - 8),
                              "tap_started": _iso(touch_start) if touch_start else None}

    # 2H story direction (used so 15m never trades on its own)
    h2_latest = None
    if "2h" in S:
        l2 = [l for l in S["2h"].relevant if l.bos_count >= 1]
        h2_latest = l2[-1].dir if l2 else None

    def levels_fn(direction, entry):
        """Unswept swing lows (sell) / highs (buy) of 2H and 1D in reach, as extra TP steps."""
        out = []
        for tf_ in ("30m", "2h", "1d"):
            s_ = S.get(tf_)
            if not s_:
                continue
            for price, _idx in s_.liquidity_levels(direction, entry):
                if abs(price - entry) <= cfg["reach_atr"] * s_.atr:
                    out.append((price, f"{tf_.upper()} {'swing low' if direction == BEAR else 'swing high'} (liquidity)", tf_))
        return out

    def not_exceeded(direction, price, since_time):
        for c in low:
            if c["time"] >= since_time and ((direction == BEAR and c["low"] < price - 1e-12)
                                            or (direction == BULL and c["high"] > price + 1e-12)):
                return False
        return True

    def objective_for(kind, tf, s, leg, latest):
        """The low (sell) / high (buy) price pulled back from = the final target (TP3)."""
        d = leg.dir
        word = "low" if d == BEAR else "high"
        if kind == "TAP":
            ex = s.extreme_between(d, leg.end_idx, latest.mss.idx)
            if ex:
                return (ex[0], f"{tf.upper()} {word} the pullback started from", tf), s.candles[ex[1]]["time"]
        elif bias and bias["pullback"] and d == bias["dir"]:
            bs, lat = bias["s"], bias["latest"]
            ex = bs.extreme_between(d, bias["leg"].mss.idx, lat.mss.idx)
            if ex:
                return (ex[0], f"1D {word} price pulled back from", bias["tf"]), bs.candles[ex[1]]["time"]
        return None, None

    # ---- 30m refinement (context only, never a signal source)
    def _legs_of(tf_):
        s_ = S.get(tf_)
        return [l for l in s_.relevant if l.bos_count >= 1] if s_ else []

    def _is_messy(tf_):
        s_ = S.get(tf_)
        legs_ = _legs_of(tf_)
        if not s_ or not legs_:
            return True                       # no readable structure at all
        n_ = len(s_.candles)
        recent = [l for l in legs_ if l.mss.idx >= n_ - cfg["messy_window"]]
        if len(recent) >= cfg["messy_legs"]:
            return True                       # too many shifts in a short time
        for a_, b_ in zip(legs_, legs_[1:]):  # opposite legs sitting on top of each other
            pa, pb = s_.leg_poi(a_), s_.leg_poi(b_)
            if a_.dir != b_.dir and pa and pb and pa.zone[0] <= pb.zone[1] and pb.zone[0] <= pa.zone[1]:
                return True
        return False

    m30_legs = _legs_of("30m")
    m30_latest = m30_legs[-1].dir if m30_legs else None
    m15_messy = _is_messy("15m")
    refinement = {"enabled": "30m" in S, "m15_messy": m15_messy, "m30_latest": m30_latest,
                  "h2_latest": h2_latest,
                  "mode": ("off" if "30m" not in S else ("30m-guided" if m15_messy else "15m-clear"))}

    setups = []

    def consider(kind, tf, s, leg, poi, tap_target=None, carrier=None):
        d = leg.dir
        with_bias = bool(bias and d == bias["dir"])
        if with_bias and touch_start is not None and leg.mss.time < touch_start:
            return  # formed before the daily tap -> not a confirmation of that zone
        if s.zone_broken(poi.zone, leg.dir, poi.formed_idx):
            return
        touches = _touch_indices(low, poi.zone, _formed_time(s, poi))
        first = low[touches[0]]["time"] if touches else None
        if touches and touches[0] >= ready_from:
            state = "READY"
        elif not touches:
            near = poi.zone[0] if d == BEAR else poi.zone[1]
            if abs(near - price) > cfg["reach_atr"] * s.atr:
                return  # too far to matter
            state = "WAIT"
        else:
            return  # already used earlier
        objective = None
        obj, obj_time = objective_for(kind, tf, s, leg, carrier)
        if obj and not_exceeded(d, obj[0], obj_time):
            objective = obj
        st = _make_setup(kind, tf, s, leg, poi, state, price, zones, cfg, with_bias, first, tap_target,
                         levels=levels_fn, objective=objective)
        if st is None:
            return
        # a leg against the bias is only a pullback: it must run INTO a structural zone
        if bias and not with_bias and st["target_type"] == "rr":
            return
        # cooperation: 15m must agree with the 2H story
        if tf == "15m" and h2_latest is not None and d != h2_latest:
            if st["target_tf"] not in ("2h", "1d"):
                return
        if tf == "15m" and "30m" in S:
            if m15_messy:
                # CASE B: 15m is messy -> the 30m must clarify it, and the setup must agree with it
                if m30_latest is None or d != m30_latest:
                    return
                st["refined_by"] = "30m"
            else:
                # CASE A/C: 15m is clear. If 30m disagrees, the 2H story must settle it, else no setup.
                if m30_latest is not None and d != m30_latest and h2_latest is None:
                    return
                st["refined_by"] = "15m (30m " + ("agrees" if m30_latest == d else "disagrees; 2H settles it") + ")"
        st["trigger"] = _trigger(st, bias_zone_info)
        st["aligned"] = {
            "bias": (bias["dir"] if bias else None), "h2_leg": h2_latest,
            "type": "trend" if with_bias else "pullback",
        }
        setups.append(st)

    for tf in ("2h", "15m"):
        s = S.get(tf)
        if not s:
            continue
        legs = [l for l in s.relevant if l.bos_count >= 1]
        if not legs:
            continue
        latest = legs[-1]
        poi = s.leg_poi(latest)
        if poi:
            consider("RETEST", tf, s, latest, poi)
        for prior in legs[:-1]:
            if prior.dir == latest.dir:
                continue
            ppoi = s.leg_poi(prior)
            if not ppoi or ppoi.formed_idx >= latest.mss.idx:
                continue
            # target of a tap = the MSS zone of the leg that carried price here
            tt = latest.mss.zone[1] if prior.dir == BEAR else latest.mss.zone[0]
            consider("TAP", tf, s, prior, ppoi, tap_target=tt, carrier=latest)

    seen, uniq = set(), []
    for st in setups:
        if st["id"] not in seen:
            seen.add(st["id"])
            uniq.append(st)
    rank_tf = {"2h": 0, "15m": 1}
    rank_type = {"RETEST": 0, "TAP": 1}
    uniq.sort(key=lambda x: (x["state"] != "READY", not x["with_bias"],
                             rank_tf[x["tf"]], rank_type[x["type"]]))
    best = next((x for x in uniq if x["state"] == "READY"), None)
    watch = next((x for x in uniq if x["state"] == "WAIT"), None)

    # ---- order plan: market order if price is AT a POI, limit orders for the POIs still ahead.
    #      Price between two structures -> BUY LIMIT and SELL LIMIT together; whichever fills,
    #      the other zone is its target and the trade continues from there.
    def _pick(pred):
        return next((x for x in uniq if pred(x)), None)
    market = best
    buy_lim = _pick(lambda x: x["state"] == "WAIT" and x["dir"] == BULL and x["entry"] < price)
    sell_lim = _pick(lambda x: x["state"] == "WAIT" and x["dir"] == BEAR and x["entry"] > price)
    if buy_lim and sell_lim:
        # each trade ends where the other begins: TP3 = the other order's entry
        _chain(buy_lim, sell_lim["entry"], f"{sell_lim['order']} zone")
        _chain(sell_lim, buy_lim["entry"], f"{buy_lim['order']} zone")
        buy_lim["pair"] = sell_lim["id"]
        sell_lim["pair"] = buy_lim["id"]
    orders = []
    for st_, kind in ((market, "MARKET"), (buy_lim, "LIMIT"), (sell_lim, "LIMIT")):
        if st_ is None:
            continue
        o = {k: st_[k] for k in ("id", "order", "tf", "type", "dir", "zone", "entry", "sl", "tp1", "tp2", "tp3",
                                 "tp_labels", "rr3", "with_bias", "trigger")}
        o["refined_by"] = st_.get("refined_by")
        o["kind"] = kind
        orders.append(o)
    if buy_lim and sell_lim:
        for o in orders:
            if o["kind"] == "LIMIT":
                other = sell_lim if o["order"] == "BUY LIMIT" else buy_lim
                o["on_fill"] = (f"If this fills, its TP3 is the {other['order']} at {other['entry']:.5g}. When TP3 is hit "
                                f"that {other['order']} fills and the {other['action'].lower()} trade continues from there. "
                                f"Keep both limits armed.")
    if market:
        mode = "MARKET" + ("+LIMIT" if (buy_lim or sell_lim) else "")
    elif buy_lim and sell_lim:
        mode = "LIMIT_BOTH"
    elif buy_lim or sell_lim:
        mode = "LIMIT"
    else:
        mode = "NONE"

    summary = {}
    for tf, s in S.items():
        legs = []
        for leg in s.relevant:
            poi = s.leg_poi(leg)
            legs.append({
                "dir": leg.dir, "bos_count": leg.bos_count,
                "mss": {"time": _iso(leg.mss.time), "level": leg.mss.level,
                        "zone": list(leg.mss.zone) if leg.mss.zone else None},
                "bos": [{"time": _iso(b.time), "level": b.level,
                         "zone": list(b.zone) if b.zone else None} for b in leg.bos],
                "poi": {"kind": poi.kind, "zone": list(poi.zone)} if poi else None,
            })
        summary[tf] = {"atr": round(s.atr, 5), "trend": s.trend, "legs": legs}

    result = {
        "price": price,
        "bias": ({"dir": bias["dir"], "strength": bias["strength"], "tf": bias["tf"],
                  "leg_mss_time": _iso(bias["leg"].mss.time),
                  "latest_leg_dir": bias["latest_dir"],
                  "latest_leg_bos_count": bias["latest"].bos_count,
                  "anchor_bos_count": bias["leg"].bos_count,
                  "anchor_mss_level": bias["leg"].mss.level,
                  "anchor_zone": list(bias["leg"].mss.zone) if bias["leg"].mss.zone else None,
                  "latest_leg_is_pullback": bias["pullback"]} if bias else None),
        "bias_zone": bias_zone_info,
        "structure": summary,
        "setups": uniq,
        "best": best,
        "watch": watch,
        "orders": orders,
        "order_mode": mode,
        "refinement": refinement,
        "fresh_zones": [{"tf": z["tf"], "dir": z["dir"], "zone": list(z["zone"]), "kind": z["kind"]} for z in zones],
    }
    result["signal"] = to_signal(result)
    return result


def to_signal(result, setup=None):
    """DB/UI-ready signal (matches save_signal fields). `setup` defaults to best READY, else best WAIT."""
    st = setup or result.get("best") or result.get("watch")
    if st is None and result.get("orders"):
        st = next((x for x in result.get("setups", []) if x["id"] == result["orders"][0]["id"]), None)
    if not st:
        return {"direction": "NEUTRAL", "verdict": "WAIT", "entry_low": None, "entry_high": None,
                "sl": None, "tp1": None, "tp2": None, "tp3": None,
                "current_price_at_signal": result["price"],
                "wait_reason": "No MSS/BOS setup is forming yet with a fresh POI in reach.",
                "setup_id": None}
    ready = st["state"] == "READY"
    return {
        "direction": "BULLISH" if st["dir"] == BULL else "BEARISH",
        "verdict": "EXECUTE" if ready else "WAIT",
        "entry_low": st["zone"][0], "entry_high": st["zone"][1],
        "entry_price": st["entry"],
        "sl": st["sl"], "tp1": st["tp1"], "tp2": st["tp2"], "tp3": st["tp3"],
        "current_price_at_signal": result["price"],
        "wait_reason": None if ready else st.get("trigger"),
        "setup_id": st["id"], "tf": st["tf"], "type": st["type"], "rr3": st["rr3"],
        "order_type": st["order"], "order_mode": result.get("order_mode"),
        "orders": result.get("orders", []),
    }


# ------------------------------------------------------- server entry point
def run_for_server(candles_by_tf, live_price=None, now=None, cfg=None):
    """
    candles_by_tf : {"D1": [...], "2H": [...], "15M": [...]} as the Node server fetched them.
    Structure is read on CLOSED candles only (a still-forming candle is dropped); the live
    price is appended as a tiny 15m bar so a zone tap is seen the moment it happens.
    """
    import time as _t
    now = float(now) if now else _t.time()
    secs = {"1d": 86400, "2h": 7200, "30m": 1800, "15m": 900}
    data = {LABELS.get(k, k): normalize_candles(v) for k, v in (candles_by_tf or {}).items()}
    closed = {}
    for tf, cs in data.items():
        if tf in secs:
            closed[tf] = [c for c in cs if c["time"] + secs[tf] <= now]
    live = None
    if "15m" in closed and closed["15m"]:
        t0 = closed["15m"][-1]["time"] + 900
        forming = next((c for c in data["15m"] if c["time"] >= t0), None)
        if forming:
            live = dict(forming)
        elif live_price:
            live = {"time": t0, "open": live_price, "high": live_price, "low": live_price, "close": live_price}
        if live and live_price:
            live["close"] = live_price
            live["high"] = max(live["high"], live_price)
            live["low"] = min(live["low"], live_price)
    return analyze(closed, cfg=cfg, live_bar=live)
