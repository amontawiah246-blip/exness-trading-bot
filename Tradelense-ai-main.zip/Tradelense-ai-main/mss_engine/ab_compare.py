"""
ab_compare.py - Version A (1D + 2H + 15m) vs Version B (1D + 2H + 30m + 15m) on the SAME history.

    python -m mss_engine.ab_compare candles_15m.json [step_bars]

candles_15m.json : list of 15m candles (epoch/time, open, high, low, close), oldest first. 2H, 30m and 1D are
                   aggregated from it. The history is replayed forward: at each step the engine only sees
                   candles up to that point (no future data).
It reports how often the two versions differ. It does NOT measure profit: to judge profit, replay the
orders it prints against the following candles with your own spread/cost assumptions.
"""
import json
import sys

from .analyzer import analyze, normalize_candles


def _agg(cs, n):
    out = []
    for i in range(0, len(cs) - n + 1, n):
        g = cs[i:i + n]
        out.append({"time": g[0]["time"], "open": g[0]["open"], "close": g[-1]["close"],
                    "high": max(x["high"] for x in g), "low": min(x["low"] for x in g)})
    return out


def compare(m15, step=16, warmup=2000):
    m15 = normalize_candles(m15)
    rows, diffs = [], 0
    for cut in range(warmup, len(m15), step):
        c = m15[:cut + 1]
        data = {"15m": c, "30m": _agg(c, 2), "2h": _agg(c, 8), "1d": _agg(c, 96)}
        try:
            a = analyze(data, cfg={"use_30m": False})
            b = analyze(data)
        except Exception:
            continue
        ids_a = sorted(o["id"] for o in a["orders"])
        ids_b = sorted(o["id"] for o in b["orders"])
        if ids_a != ids_b:
            diffs += 1
            rows.append({"time": c[-1]["time"], "A": ids_a, "B": ids_b, "m15_messy": b["refinement"]["m15_messy"],
                         "m30": b["refinement"]["m30_latest"]})
    return {"checked_points": len(range(warmup, len(m15), step)), "points_where_orders_differ": diffs, "examples": rows[:25]}


if __name__ == "__main__":
    data = json.load(open(sys.argv[1]))
    print(json.dumps(compare(data, int(sys.argv[2]) if len(sys.argv) > 2 else 16), indent=1))
