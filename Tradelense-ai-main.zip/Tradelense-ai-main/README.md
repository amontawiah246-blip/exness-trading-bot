<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/b61e4b19-82c1-4ac6-ac25-df7e7e5f07c1

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Day Trading mode (MSS · BOS · POI)
The default mode now uses a structure-only strategy on Daily + 2H + 15M. See [STRATEGY.md](STRATEGY.md).
Tests: `npm run test:mss`. Raw engine reading for tuning: `GET /api/mss-structure?asset=XAUUSD`.
